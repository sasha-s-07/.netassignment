﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XmlTest.Models
{
    public class Person
    {
        public string Job { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
