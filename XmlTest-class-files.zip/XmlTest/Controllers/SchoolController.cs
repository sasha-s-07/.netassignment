﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Xml;
using System.Xml.Xsl;
using System.IO; //to be able to create a stream

namespace XmlTest.Controllers
{
    public class SchoolController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string Type)
        {
            //load the XML file
            XmlDocument xml = new XmlDocument();
            xml.Load(Request.PathBase + "App_Data/schools.xml");

            //load the XSLT
            XslCompiledTransform xsl = new XslCompiledTransform();
            XsltArgumentList args = new XsltArgumentList();
            args.AddParam("schooltype", "", Type);

            StringWriter str = new StringWriter();
            xsl.Transform(xml, args, str);

            ViewBag.Output = str.ToString();
            //pass the parameter value to XSLT
            return View();
        }
    }
}